1. npm install create-react-app 
   - will download react project template on your machine

2. npx create-react-app demo
   - will extract the template downloaded earlier 
     & create a new project out of it
     with basic structure ready

3. npm start
    - This command will find all .js files
    - combine all & compress JS code
    - refer it as "bundle.js"
    - reference to bundle.js is added inside "index.html"
    - react developement server starts listening at port 
      3000
    - Default browser gets opened and a call is shooted 
      automatically to http://127.0.0.1:3000/index.html

    - index.html + bundle.js will be downloaded on the 
       browser side

    - bundle.js has code w.r.t. Single Page Application


